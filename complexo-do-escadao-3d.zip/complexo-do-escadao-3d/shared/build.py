# Junta as partes da simulação em shared/sim.js (o arquivo que o servidor e o navegador usam).
import os
d=os.path.dirname(os.path.abspath(__file__))
r=lambda f: open(os.path.join(d,f),encoding='utf-8').read()
head="""/* Complexo do Escadão 3D — simulação compartilhada (mapa, colisão, navegação e regras).
   Roda no servidor (Node) e no navegador (modo treino). Sem dependências.
   Gerado por shared/build.py a partir de _map.js, _world.js e _game.js. */
(function (root) {
'use strict';
"""
tail="""
const API = { CONFIG, TEAM, BOT_NAMES, DIFF_FPS, CELL, GX, GZ, NC, MW, ML, K_VOID, K_AVE, K_WALK, K_STREET, K_ESC, K_BECO, K_ROOF, K_BLOCK, K_PLAZA, WALKABLE,
  B_MURO, B_TANK, B_GUARD, B_WALL, B_INVIS, B_TANK2, B_SAND, B_JERSEY, B_BRICKS, B_BARREL, B_SUPPLY, STEP_UP,
  buildMap, makeWorld, makeGame, terrain, aveX, foldZ, mulberry, h2, clamp, sm, lerp, angDiff, STREETS, SUPPLY, PRACA, CANAL_ST, WALK_X0, WALK_X1, WALK_H, STATION,
  get ESC_LAND() { return ESC_LAND; } };
if (typeof module !== 'undefined' && module.exports) module.exports = API; else root.EscSim = API;
})(typeof window !== 'undefined' ? window : globalThis);
"""
open(os.path.join(d,'sim.js'),'w',encoding='utf-8').write(head+r('_map.js')+"\n"+r('_world.js')+"\n"+r('_game.js')+tail)
print('sim.js gerado')
