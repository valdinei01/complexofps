// Servidor do Complexo do Escadão 3D: arquivos do jogo + salas online (Socket.IO).
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const { Server } = require('socket.io');
const { RoomManager, world } = require('./rooms.js');

const PORT = process.env.PORT || 3000;
const ROOT = path.join(__dirname, '..');
const PUBLIC = path.join(ROOT, 'public');
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.mp3': 'audio/mpeg', '.png': 'image/png', '.json': 'application/json', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };

function serve(req, res) {
  let url = decodeURIComponent((req.url || '/').split('?')[0]);
  if (url === '/health') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('ok'); }
  let file;
  if (url === '/shared/sim.js') file = path.join(ROOT, 'shared', 'sim.js');
  else { if (url === '/' || url.startsWith('/sala/')) url = '/index.html'; file = path.join(PUBLIC, path.normalize(url)); if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end(); } }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Não encontrado'); }
    const ext = path.extname(file).toLowerCase();
    res.writeHead(200, { 'Content-Type': TYPES[ext] || 'application/octet-stream', 'Cache-Control': ext === '.mp3' ? 'public, max-age=86400' : 'no-cache' });
    res.end(data);
  });
}

const server = http.createServer(serve);
const io = new Server(server, { cors: { origin: '*' }, pingInterval: 10000, pingTimeout: 15000, maxHttpBufferSize: 64 * 1024 });
world(); // gera o mapa uma vez ao iniciar
new RoomManager(io);
server.listen(PORT, () => console.log('Complexo do Escadão 3D rodando na porta ' + PORT));
